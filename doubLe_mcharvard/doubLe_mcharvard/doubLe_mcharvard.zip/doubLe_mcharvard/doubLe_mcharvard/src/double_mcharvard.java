import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class double_mcharvard {

    int pc = 0;
    int [] instructionMemory = new int[1024];
    int [] dataMemory = new int[2048];
    int [] gprs = new int[64];
    int [] statusRegister = new int[8];

    public static void main(String[] args) {
        String assemblyCode = "SUB R1, R2"; // Example assembly code

        String binaryCode = parseAssemblyCode(assemblyCode);
        System.out.println("Binary Code: " + binaryCode);

        System.out.println(Integer.parseInt(Integer.toBinaryString(0b10000000 + 0b10000000).substring(1),2));

    }

    public static String parseAssemblyCode(String assemblyCode) {
        // Split the assembly code into different parts
        String[] parts = assemblyCode.split("\\s*,\\s*|\\s+");

        String opcode = parts[0]; // The first part is the opcode

        // Transform the opcode into binary
        String binaryOpcode = getBinaryOpcode(opcode);

        // Generate binary code based on the opcode
        StringBuilder binaryCode = new StringBuilder(binaryOpcode);

        for (int i = 1; i < parts.length; i++) {
            String operand = parts[i];

            // Transform the operand into binary
            String binaryOperand = getBinaryOperand(operand);

            // Append the binary operand to the binary code
            binaryCode.append(binaryOperand);
        }

        return binaryCode.toString();
    }

    public void TextFileToArray(String filePath) {
        List<String> lines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        int i = 0;
        for (String s : lines)
        {
            instructionMemory[i] = Integer.parseInt(parseAssemblyCode(s),2);
            i++;
        }

    }

    public int fetch() {
        if (pc < 0 || pc >= instructionMemory.length) {
            throw new IllegalArgumentException("Invalid program counter");
        }

        return instructionMemory[pc];
    }


    public static String getBinaryOpcode(String opcode) {
        opcode = opcode.toUpperCase();
        switch (opcode) {
            case "ADD":
                return "0000";
            case "SUB":
                return "0001";
            case "MUL":
                return "0010";
            case "LDI":
                return "0011";
            case "BEQZ":
                return "0100";
            case "AND":
                return "0101";
            case "OR":
                return "0110";
            case "JR":
                return "0111";
            case "SLC":
                return "1000";
            case "SRC":
                return "1001";
            case "LB":
                return "1010";
            case "SB":
                return "1011";
            // Add more opcode cases as needed
            default:
                throw new IllegalArgumentException("Unknown opcode: " + opcode);
        }
    }

    public static String getBinaryOperand(String operand) {
        // Transform the operand into binary representation
        // Implement the logic to convert the operand into binary based on your specific requirements

        // Dummy implementation: assuming operand is a register

        String operandInDecimal = "";
        if(operand.charAt(0)=='R')
            operandInDecimal = operand.substring(1);
        else
            operandInDecimal = operand;

        String operandInBinary = Integer.toBinaryString(Integer.parseInt(operandInDecimal));

        if(operandInBinary.length()>6){
            throw new IllegalArgumentException("Operand too big.");
        }

        while(operandInBinary.length()<6){
            operandInBinary = "0".concat(operandInBinary);
        }

        return operandInBinary;
    }

    public void decode(int instruction){
        String opcode = Integer.toBinaryString(instruction).substring(0,4);
        String operand1 = Integer.toBinaryString(instruction).substring(4, 10);
        String operand2 = Integer.toBinaryString(instruction).substring(10, 16);
        int opcode_ = Integer.parseInt(opcode, 2);
        int operand1_ = Integer.parseInt(operand1, 2);
        int operand2_ = Integer.parseInt(operand2, 2);
        execute(opcode_, operand1_, operand2_);
    }

    public void execute(int opcode, int operand1, int operand2){
        switch (opcode) {
            case 0b0000:
                if(Integer.bitCount(gprs[operand1] + gprs[operand2]) > 8) {
                    statusRegister[4] = 1;
                    gprs[operand1] = Integer.parseInt(Integer.toBinaryString(gprs[operand1] + gprs[operand2]).substring(1),2);
                }
                else {
                    statusRegister[4] = 0;
                    gprs[operand1] = gprs[operand1] + gprs[operand2];
                }
                break;
            case 0b0001:
                gprs[operand1] = gprs[operand1] - gprs[operand2];
            case 0b0010:
                gprs[operand1] = gprs[operand1] * gprs[operand2];
            case 0b0011:
                gprs[operand1] = operand2;
            case 0b0100:
                if (gprs[operand1] == 0)
                {
                    pc = pc + operand2;
                    break;
                }
            case 0b0101:
                gprs[operand1] = gprs[operand1] & gprs[operand2];
                break;
            case 0b0110:
                gprs[operand1] = gprs[operand1] | gprs[operand2];
                break;
            case 0b0111:
                pc = Integer.parseInt(Integer.toBinaryString(gprs[operand1]).concat(Integer.toBinaryString(gprs[operand2])), 2);
                break;
            case 0b1000:
                gprs[operand1] = gprs[operand1] << operand2 | gprs[operand1] >>> 8 - operand2;
                break;
            case 0b1001:
                gprs[operand1] = gprs[operand1] >>> operand2 | gprs[operand1] << 8 - operand2;
                break;
            case 0b1010:
                gprs[operand1] =dataMemory[operand2] ;
                break;
            case 0b1011:
                dataMemory[operand2] = gprs[operand2];
                break;
            // Add more opcode cases as needed
            default:
                throw new IllegalArgumentException("Unknown opcode: " + opcode);
        }
    }
    
    public void Pipeline( int totalInstructions) {

            int pipelineSize = 3; // Number of instructions running in parallel
            int clockCycles = 3 + ((totalInstructions - 1) * 1); // Number of clock cycles

            // Create an array to hold the instructions
            String[] instructions = new String[totalInstructions];
            for (int i = 0; i < totalInstructions; i++) {
                instructions[i] = "Instruction " + (i + 1);
            }

            // Execute the pipeline
            int cycle = 1;
            for (int i = 0; i < clockCycles; i++) {
                for (int j = 0; j < pipelineSize; j++) {
                    int instructionIndex = i - j;
                    if (instructionIndex >= 0 && instructionIndex < totalInstructions) {
                        System.out.print("Cycle " + cycle + " " + instructions[instructionIndex] + " ");
                    }
                }
                cycle++;
                System.out.println();
            }

    }

}

